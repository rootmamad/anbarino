from django.shortcuts import render
from .models import Product
from transaction.models import Transaction
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.http import JsonResponse

# Create your views here.
def view(request):
    products = Product.objects.all()
    ctx = {
        'best_selling_products': Product.objects.order_by('-purchased_quantity')[:10],
        'new_products': Product.objects.order_by('-created_at')[:10],
        'low_stock_products': Product.objects.filter(quantity__lt=10)[:10],
        'bulk_products': Product.objects.filter(quantity__gte=100)[:10],
    }

    return render(request, 'products/index.html', ctx)#{'products': products})


@login_required
def cart_view(request):
    cart_items = Transaction.objects.filter(
        user=request.user,
        transaction_type=Transaction.PURCHASE,
        is_approved=False
    ).select_related('product')

    return render(request, 'products/cart.html', {
        'cart_items': cart_items
    })


@require_POST
def remove_from_cart(request, product_id):
    try:
        transaction = Transaction.objects.filter(
            user=request.user,
            product__id=product_id,
            transaction_type=Transaction.PURCHASE,
            is_approved=False
        )
        transaction.delete()
        return JsonResponse({'status': 'ok'})
    except Transaction.DoesNotExist:
        print("transaction does not exist")
        return JsonResponse({'status': 'not_found'}, status=404)