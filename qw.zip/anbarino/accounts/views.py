from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib import messages
from transaction.models import UserBalance
from django.contrib.auth import logout
from django.contrib.auth.hashers import make_password


refer = []
def signup_view(request):
    if request.method == 'POST':

            data = request.POST
            user = User.objects.create_user(
                username=data['username'],
               password=data['password'],
                email=data['email'],
                first_name=data['first_name'],
                last_name=data['last_name'],
            )

            login(request,user)
            UserBalance.objects.create(user=user,balance=0)
            return redirect(refer[-1])
    else:
        refer.append( request.META.get('HTTP_REFERER'))

    return render(request, 'accounts/signup.html')

def login_view(request):
    if request.method == 'POST':
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user:
            login(request, user)
            return redirect('home')
        messages.error(request, 'اطلاعات ورود نادرست است.')
    return render(request, 'accounts/login.html')

def forgot_password_view(request):
    password = None
    if request.method == 'POST':
        username = request.POST['username']
        national_id = request.POST['national_id']
        try:
            user = User.objects.get(username=username, national_id=national_id)
            password = user.password  # فرض بر اینکه رمز نگهداری میشه (غیراستاندارد!)
        except User.DoesNotExist:
            messages.error(request, 'کاربری با این مشخصات یافت نشد.')
    return render(request, 'accounts/forgot_password.html', {'password': password})

@login_required(login_url='/login')
def logout_view(request):
    logout(request)
    return redirect('/')


def login_view(request):
    if request.method == 'POST':
        username_or_email = request.POST.get('username_or_email')
        password = request.POST.get('password')

        # اول با نام کاربری تلاش می‌کنیم
        user = authenticate(request, username=username_or_email, password=password)

        # اگر نام کاربری درست نبود، ایمیل رو امتحان می‌کنیم
        if user is None:
            try:
                user_obj = User.objects.get(email=username_or_email)
                user = authenticate(request, username=user_obj.username, password=password)
            except User.DoesNotExist:
                user = None

        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            messages.error(request, "نام کاربری یا رمز عبور اشتباه است.")
            return render(request, 'accounts/login.html')
    else:
        return render(request, 'accounts/login.html')



def password_reset_view(request):
    context = {
        "show_password_fields": False,
        "username": "",
        "email": "",
    }

    if request.method == "POST":
        # اگر مرحله اول هستیم (بررسی نام کاربری و ایمیل)
        if "password" not in request.POST:
            username = request.POST.get("username", "").strip()
            email = request.POST.get("email", "").strip()

            context["username"] = username
            context["email"] = email

            if not username or not email:
                messages.error(request, "لطفا همه فیلدها را پر کنید.")
            else:
                try:
                    user = User.objects.get(username=username, email=email)
                    context["show_password_fields"] = True
                    messages.success(request, "کاربر یافت شد. لطفا رمز جدید را وارد کنید.")
                except User.DoesNotExist:
                    messages.error(request, "نام کاربری و ایمیل مطابقت ندارند.")

        # اگر مرحله دوم هستیم (تغییر رمز)
        else:
            username = request.POST.get("username", "").strip()
            email = request.POST.get("email", "").strip()
            password = request.POST.get("password", "")
            confirm_password = request.POST.get("confirm_password", "")

            context["username"] = username
            context["email"] = email
            context["show_password_fields"] = True

            if not password or not confirm_password:
                messages.error(request, "لطفا هر دو فیلد رمز را پر کنید.")
            elif len(password) < 8:
                messages.error(request, "رمز عبور باید حداقل ۸ کاراکتر باشد.")
            elif password != confirm_password:
                messages.error(request, "رمز عبور با تکرار آن مطابقت ندارد.")
            else:
                try:
                    user = User.objects.get(username=username, email=email)
                    user.password = make_password(password)
                    user.save()
                    messages.success(request, "رمز عبور با موفقیت تغییر کرد. اکنون می‌توانید وارد شوید.")
                    login(request, user)
                    return redirect('/')
                except User.DoesNotExist:
                    messages.error(request, "کاربر یافت نشد.")

    return render(request, "accounts/password_reset.html", context)